package com.example.only_funds

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
