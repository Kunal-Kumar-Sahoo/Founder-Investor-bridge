# only_funds

### SSIP problem statement: **Mind-to-Market Startup Journey tracker**

## Developed by
- [Dev Parikh](https://github.com/Dev79844)
- [Jay Nakum](https://github.com/JayNakum)
- [Kunal Kumar Sahoo](https://github.com/Kunal-Kumar-Sahoo)
- [Kishan Pipariya](https://github.com/KishanPipariya)
- [Tanish Patel](https://github.com/tanishpatel0106)
